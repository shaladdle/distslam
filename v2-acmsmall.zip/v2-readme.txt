ACM Transactions and Journals (small trim Size) - V2 (April 2012)
-----------------------------------------------------------------

The following files are available in the v2-acmlarge.zip archive:

acmsmall.cls	     			- This is V1.4 of the LaTeX2e class file for the 'acmsmall template/format'
ACM-Reference-Format-Journals.bst	- This is the bibliography style file for the New ACM Reference Format (March 2012)
acmsmall-sample-bibfile.bib		- This is the bibliography database file
v2-acmsmall-guide.pdf			- This is a PDF of the "author guidelines' for the acmlsmall template
v2-acmsmall-sample.pdf			- This is a PDF file showing what YOU should obtain
					  when YOU compile the sample source .tex file

v2-acmsmall-sample.tex			- the revised (v2) source sample .tex file 
v2-acmsmall-sample.bbl			- the bbl file as a result of 'BibTeX'ing 
acmsmall-mouse.eps			- Graphics file used in sample
acmsmall-mouse.pdf			- a graphics file in PDF format, (compatible with pdflatex)
algorithm2e.sty				- Algorithm package used in sample
url.sty					- URL package used in formatting the references
readme.txt				- This file!

Happy (La)TeXing!!!

Aptara/Gerry Murray - April 2012
